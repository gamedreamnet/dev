import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type WorkflowStep = 'PROBLEM' | 'PROBLEM_EXPANDED' | 'PLAN' | 'IMPLEMENTATION' | 'DIFF' | 'DOCUMENTATION';

export type TicketSeverity = 'S1' | 'S2' | 'S3' | 'S4';

export type TicketTag = 'AI' | 'Quest' | 'Core' | 'Datapack' | 'Network' | 'Geo' | 'Economy' | 'Security' | 'Login' | 'Config';

export interface Attachment {
  id: string;
  name: string;
  type: 'image' | 'log';
  content: string; // dataURL for image, text for log
}

export interface TicketProblem {
  title: string;
  description?: string;
  reproductionSteps?: string;
  environment?: 'prod' | 'test';
  version?: string;
  affectedAccounts?: string;
  timestamp?: string;
  logs?: string;
  configDiff?: string;
  attachments: Attachment[];
}

export interface TicketExpanded {
  severity: TicketSeverity;
  tags: TicketTag[];
  markdown: string;
  accepted: boolean;
}

export interface TicketPlan {
  files: string[];
  currentLogic: string;
  minimalScope: string;
  sourceImpact: string;
  risks: string;
  testPlan: string;
  markdown: string;
}

export interface Ticket {
  id: string;
  createdAt: string;
  updatedAt: string;
  status: 'open' | 'closed';
  currentStep: WorkflowStep;
  
  problem: TicketProblem;
  expanded?: TicketExpanded;
  plan?: TicketPlan;
}

interface TicketStore {
  tickets: Ticket[];
  mode: 'bug-only' | 'full';
  
  setMode: (mode: 'bug-only' | 'full') => void;
  createTicket: (problem: TicketProblem) => string;
  updateTicket: (id: string, updates: Partial<Ticket>) => void;
  deleteTicket: (id: string) => void;
  getTicket: (id: string) => Ticket | undefined;
  
  // Workflow actions
  generateExpanded: (id: string, severity: TicketSeverity, tags: TicketTag[]) => void;
  acceptExpanded: (id: string) => void;
  savePlan: (id: string, plan: TicketPlan) => void;
}

// Helper to generate markdown
const generateExpandedMarkdown = (problem: TicketProblem, severity: TicketSeverity, tags: TicketTag[]) => {
  const attachmentsInfo = problem.attachments.length > 0 
    ? `\n## Załączniki\n${problem.attachments.map(a => `- ${a.name} (${a.type})`).join('\n')}`
    : '';

  const logContent = problem.attachments.filter(a => a.type === 'log').map(a => `### Log: ${a.name}\n\`\`\`\n${a.content.substring(0, 500)}...\n\`\`\``).join('\n\n');

  return `# ROZSZERZONY PROBLEM (EXPANDED)
**Priorytet:** ${severity}
**Tagi:** ${tags.join(', ')}
**Data:** ${new Date().toISOString()}

## Opis
${problem.description || 'Brak opisu'}

${attachmentsInfo}

${logContent ? `## Analiza Logów\n${logContent}` : ''}

## Kroki reprodukcji
${problem.reproductionSteps || 'Do ustalenia na podstawie analizy'}

## Środowisko
- **Env:** ${problem.environment || 'Nieokreślone'}
- **Wersja:** ${problem.version || 'Nieokreślona'}
- **Konta:** ${problem.affectedAccounts || 'Brak'}

## Pytania
- [ ] Jakie są dokładne okoliczności wystąpienia błędu?
- [ ] Czy problem występuje na czystym datapacku?
`;
};

export const useTicketStore = create<TicketStore>()(
  persist(
    (set, get) => ({
      tickets: [],
      mode: 'bug-only',
      
      setMode: (mode) => set({ mode }),
      
      createTicket: (problem) => {
        const id = Math.random().toString(36).substring(2, 15);
        const newTicket: Ticket = {
          id,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
          status: 'open',
          currentStep: 'PROBLEM',
          problem
        };
        
        set((state) => ({ tickets: [newTicket, ...state.tickets] }));
        return id;
      },
      
      updateTicket: (id, updates) => {
        set((state) => ({
          tickets: state.tickets.map((t) => 
            t.id === id ? { ...t, ...updates, updatedAt: new Date().toISOString() } : t
          )
        }));
      },
      
      deleteTicket: (id) => {
        set((state) => ({
          tickets: state.tickets.filter((t) => t.id !== id)
        }));
      },
      
      getTicket: (id) => get().tickets.find((t) => t.id === id),
      
      generateExpanded: (id, severity, tags) => {
        const ticket = get().getTicket(id);
        if (!ticket) return;
        
        const markdown = generateExpandedMarkdown(ticket.problem, severity, tags);
        
        set((state) => ({
          tickets: state.tickets.map((t) => 
            t.id === id ? {
              ...t,
              currentStep: 'PROBLEM_EXPANDED',
              updatedAt: new Date().toISOString(),
              expanded: {
                severity,
                tags,
                markdown,
                accepted: false
              }
            } : t
          )
        }));
      },
      
      acceptExpanded: (id) => {
         set((state) => ({
          tickets: state.tickets.map((t) => 
            t.id === id && t.expanded ? {
              ...t,
              currentStep: 'PLAN',
              updatedAt: new Date().toISOString(),
              expanded: {
                ...t.expanded,
                accepted: true
              }
            } : t
          )
        }));
      },
      
      savePlan: (id, plan) => {
         set((state) => ({
          tickets: state.tickets.map((t) => 
            t.id === id ? {
              ...t,
              currentStep: 'IMPLEMENTATION', // Move to next step
              updatedAt: new Date().toISOString(),
              plan: {
                ...plan,
                markdown: `# PLAN IMPLEMENTACJI
**Pliki docelowe:**
${plan.files.map(f => `- ${f}`).join('\n')}

## Obecna logika
${plan.currentLogic}

## Minimalny zakres zmian
${plan.minimalScope}

## Wpływ na źródła (Source Impact)
${plan.sourceImpact}

## Ryzyka i regresje
${plan.risks}

## Plan testów
${plan.testPlan}
`
              }
            } : t
          )
        }));
      }
    }),
    {
      name: 'gamedream-store',
    }
  )
);
