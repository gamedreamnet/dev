import { WorkflowStep } from '@/lib/store';
import { cn } from '@/lib/utils';
import { CheckCircle2, Circle, ArrowRight } from 'lucide-react';

interface WorkflowStepperProps {
  currentStep: WorkflowStep;
}

const STEPS: WorkflowStep[] = ['PROBLEM', 'PROBLEM_EXPANDED', 'PLAN', 'IMPLEMENTATION', 'DIFF', 'DOCUMENTATION'];

const STEP_LABELS: Record<WorkflowStep, string> = {
  'PROBLEM': 'PROBLEM',
  'PROBLEM_EXPANDED': 'ROZSZERZONY',
  'PLAN': 'PLAN',
  'IMPLEMENTATION': 'IMPLEMENTACJA',
  'DIFF': 'DIFF',
  'DOCUMENTATION': 'DOKUMENTACJA'
};

export function WorkflowStepper({ currentStep }: WorkflowStepperProps) {
  const currentIndex = STEPS.indexOf(currentStep);

  return (
    <div className="w-full mb-8 overflow-x-auto pb-2">
      <div className="flex items-center min-w-max">
        {STEPS.map((step, index) => {
          const isCompleted = index < currentIndex;
          const isCurrent = index === currentIndex;
          const isPending = index > currentIndex;

          return (
            <div key={step} className="flex items-center">
              <div className={cn(
                "flex items-center gap-2 px-3 py-2 rounded border transition-all duration-300",
                isCompleted && "bg-primary/10 border-primary/30 text-primary",
                isCurrent && "bg-primary text-black border-primary shadow-[0_0_15px_rgba(255,160,0,0.4)] font-bold transform scale-105",
                isPending && "bg-muted/30 border-white/5 text-muted-foreground"
              )}>
                {isCompleted ? (
                  <CheckCircle2 className="w-4 h-4" />
                ) : (
                  <span className="w-4 h-4 flex items-center justify-center text-[10px] border rounded-full border-current">
                    {index + 1}
                  </span>
                )}
                <span className="text-xs font-mono tracking-wider">{STEP_LABELS[step]}</span>
              </div>

              {index < STEPS.length - 1 && (
                <div className="px-2">
                  <div className={cn("h-[1px] w-8", isCompleted ? "bg-primary" : "bg-muted")}></div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
