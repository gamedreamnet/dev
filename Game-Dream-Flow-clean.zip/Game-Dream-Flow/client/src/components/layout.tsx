import { Link, useLocation } from 'wouter';
import { useTicketStore } from '@/lib/store';
import { cn } from '@/lib/utils';
import { LayoutDashboard, PlusCircle, AlertTriangle, Settings, FileCode, Shield } from 'lucide-react';

export default function Layout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();
  const { mode, setMode } = useTicketStore();

  const navItems = [
    { href: '/', label: 'Dashboard', icon: LayoutDashboard },
    { href: '/new', label: 'Nowe Zgłoszenie', icon: PlusCircle },
    { href: '/about', label: 'Zasady i Protokoły', icon: Shield },
  ];

  return (
    <div className="flex h-screen w-full bg-background text-foreground overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-64 flex-shrink-0 border-r border-border bg-card/50 backdrop-blur-md flex flex-col">
        <div className="p-6 border-b border-border">
          <h1 className="font-display text-2xl font-bold tracking-wider text-primary text-glow">
            GAMEDREAM
          </h1>
          <p className="text-xs text-muted-foreground mt-1 tracking-widest uppercase">
            Interlude C6 Dev Console
          </p>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.href;
            return (
              <Link key={item.href} href={item.href}>
                <div className={cn(
                  "flex items-center gap-3 px-4 py-3 rounded-md text-sm font-medium transition-all duration-200 cursor-pointer group border border-transparent",
                  isActive 
                    ? "bg-primary/10 text-primary border-primary/20 shadow-[0_0_10px_rgba(255,160,0,0.1)]" 
                    : "text-muted-foreground hover:text-foreground hover:bg-white/5"
                )}>
                  <Icon className={cn("w-5 h-5", isActive ? "text-primary" : "group-hover:text-primary transition-colors")} />
                  {item.label}
                </div>
              </Link>
            );
          })}
        </nav>

        {/* System Status / Mode */}
        <div className="p-4 border-t border-border bg-black/20">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-xs font-mono text-muted-foreground">TRYB</span>
              <div className="flex bg-muted/50 rounded p-1">
                <button
                  onClick={() => setMode('bug-only')}
                  className={cn("px-2 py-0.5 text-[10px] rounded transition-colors", mode === 'bug-only' ? "bg-primary text-black font-bold" : "text-muted-foreground")}
                >
                  BUG
                </button>
                <button
                  onClick={() => setMode('full')}
                  className={cn("px-2 py-0.5 text-[10px] rounded transition-colors", mode === 'full' ? "bg-primary text-black font-bold" : "text-muted-foreground")}
                >
                  FULL
                </button>
              </div>
            </div>

            {/* Path Legend */}
            <div className="space-y-2 pt-2 border-t border-white/5">
              <span className="text-[10px] uppercase text-muted-foreground font-bold">Mapowanie Ścieżek</span>
              <div className="flex items-center gap-2 text-[10px] font-mono">
                <div className="w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
                <span className="text-blue-400">TEMPLATE</span>
                <span className="text-muted-foreground truncate">src/main/resources</span>
              </div>
              <div className="flex items-center gap-2 text-[10px] font-mono">
                <div className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></div>
                <span className="text-emerald-400">RUNTIME</span>
                <span className="text-muted-foreground truncate">runtime/game/data</span>
              </div>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto relative">
        <div className="absolute inset-0 bg-[linear-gradient(rgba(0,0,0,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(0,0,0,0.1)_1px,transparent_1px)] bg-[size:20px_20px] pointer-events-none"></div>
        {children}
      </main>
    </div>
  );
}
