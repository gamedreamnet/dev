import Layout from '@/components/layout';
import { useTicketStore } from '@/lib/store';
import { Link } from 'wouter';
import { Plus, Clock, FileText, AlertTriangle } from 'lucide-react';
import { formatDistanceToNow } from 'date-fns';
import { pl } from 'date-fns/locale';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function Dashboard() {
  const { tickets, deleteTicket } = useTicketStore();

  return (
    <Layout>
      <div className="p-8 max-w-7xl mx-auto">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-display font-bold text-white mb-2">Dev Console</h1>
            <p className="text-muted-foreground font-mono text-sm">Aktywne Zgłoszenia: {tickets.filter(t => t.status === 'open').length}</p>
          </div>
          <Link href="/new">
            <Button className="bg-primary hover:bg-primary/90 text-black font-bold">
              <Plus className="w-4 h-4 mr-2" />
              Nowe Zgłoszenie
            </Button>
          </Link>
        </div>

        {tickets.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-[400px] border-2 border-dashed border-white/10 rounded-lg bg-black/20">
            <FileText className="w-12 h-12 text-muted-foreground mb-4 opacity-50" />
            <h3 className="text-xl font-display text-muted-foreground mb-2">Brak Aktywnych Operacji</h3>
            <p className="text-sm text-muted-foreground/60 mb-6">Zainicjuj nowy workflow, aby rozpocząć.</p>
            <Link href="/new">
              <Button variant="outline" className="border-primary/50 text-primary hover:bg-primary/10">
                Inicjuj Workflow
              </Button>
            </Link>
          </div>
        ) : (
          <div className="grid gap-4">
            {tickets.map((ticket) => (
              <div 
                key={ticket.id} 
                className="group relative bg-card/40 backdrop-blur-sm border border-white/5 hover:border-primary/50 transition-all duration-300 p-5 rounded-lg overflow-hidden"
              >
                <div className="absolute top-0 left-0 w-1 h-full bg-primary/0 group-hover:bg-primary transition-all duration-300"></div>
                
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-3">
                      <h3 className="font-display text-lg font-semibold text-white group-hover:text-primary transition-colors">
                        {ticket.problem.title}
                      </h3>
                      {ticket.expanded?.severity && (
                        <Badge variant="outline" className={
                          ticket.expanded.severity === 'S1' ? "border-red-500 text-red-500" :
                          ticket.expanded.severity === 'S2' ? "border-orange-500 text-orange-500" :
                          "border-primary/50 text-primary"
                        }>
                          {ticket.expanded.severity}
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground line-clamp-1 max-w-2xl font-mono">
                      {ticket.problem.description}
                    </p>
                  </div>

                  <div className="flex items-center gap-4">
                    <div className="text-right">
                      <div className="flex items-center gap-1 text-xs text-muted-foreground font-mono mb-1">
                        <Clock className="w-3 h-3" />
                        {formatDistanceToNow(new Date(ticket.updatedAt), { addSuffix: true, locale: pl })}
                      </div>
                      <Badge variant="secondary" className="bg-white/5 text-xs font-mono">
                        {ticket.currentStep}
                      </Badge>
                    </div>
                    
                    <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                      <Link href={`/ticket/${ticket.id}`}>
                        <Button size="sm" variant="outline" className="h-8 border-primary/30 hover:border-primary text-primary hover:bg-primary/10">
                          Otwórz
                        </Button>
                      </Link>
                      <Button 
                        size="sm" 
                        variant="ghost" 
                        className="h-8 text-destructive hover:bg-destructive/10"
                        onClick={() => deleteTicket(ticket.id)}
                      >
                        Usuń
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </Layout>
  );
}
