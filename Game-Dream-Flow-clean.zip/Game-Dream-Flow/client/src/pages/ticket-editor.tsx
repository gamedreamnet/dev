import Layout from '@/components/layout';
import { WorkflowStepper } from '@/components/workflow-stepper';
import { useTicketStore, TicketSeverity, TicketTag, Attachment } from '@/lib/store';
import { useParams, useLocation } from 'wouter';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from '@/components/ui/form';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import ReactMarkdown from 'react-markdown';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { AlertTriangle, Lock, Download, Copy, Save, FileCode2, FileText, Shield, CheckCircle2, Upload, X, Image as ImageIcon, FileTerminal } from 'lucide-react';
import { useEffect, useState, useRef } from 'react';
import { cn } from '@/lib/utils';

// --- VALIDATION & SCHEMAS ---

const problemSchema = z.object({
  title: z.string().min(5, "Tytuł zbyt krótki"),
  description: z.string().optional(),
  // Made optional for simple flow
  reproductionSteps: z.string().optional(),
  environment: z.enum(['prod', 'test']).optional(),
  version: z.string().optional(),
  affectedAccounts: z.string().optional(),
  logs: z.string().optional(),
  configDiff: z.string().optional(),
});

const planSchema = z.object({
  files: z.string().min(1, "Wymień dotknięte pliki"),
  currentLogic: z.string().min(10, "Wyjaśnij obecną logikę"),
  minimalScope: z.string().min(10, "Zdefiniuj minimalny zakres"),
  sourceImpact: z.string().min(5, "Source vs Runtime?"),
  risks: z.string().min(5, "Zidentyfikuj ryzyka"),
  testPlan: z.string().min(10, "Jak przetestować?"),
});

// --- COMPONENTS ---

const C6_FORBIDDEN_TERMS = ['Kamael', 'Gracia', 'Classic', 'Vitality', 'Attribute System', 'Talisman'];

function ComplianceCheck({ text }: { text: string }) {
  if (!text) return null;
  const violations = C6_FORBIDDEN_TERMS.filter(term => text.toLowerCase().includes(term.toLowerCase()));
  
  if (violations.length === 0) return null;

  return (
    <Alert variant="destructive" className="mb-4 bg-destructive/10 border-destructive/50 text-destructive-foreground">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>Ostrzeżenie o zgodności z C6</AlertTitle>
      <AlertDescription>
        Tekst zawiera terminy zabronione w Interlude C6: <strong>{violations.join(', ')}</strong>. 
        Upewnij się, że nie implementujesz funkcjonalności z nowszych kronik.
      </AlertDescription>
    </Alert>
  );
}

export default function TicketEditor() {
  const { id } = useParams<{ id: string }>();
  const [location, setLocation] = useLocation();
  const { createTicket, getTicket, generateExpanded, acceptExpanded, savePlan, mode } = useTicketStore();
  
  // Local state for the "Expanded" generation form
  const [severity, setSeverity] = useState<TicketSeverity>('S3');
  const [selectedTags, setSelectedTags] = useState<TicketTag[]>([]);
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const ticket = id ? getTicket(id) : undefined;
  const isNew = !id;

  // Sync attachments from ticket if editing
  useEffect(() => {
    if (ticket && ticket.problem.attachments) {
      setAttachments(ticket.problem.attachments);
    }
  }, [ticket]);

  // --- FORMS ---
  const problemForm = useForm<z.infer<typeof problemSchema>>({
    resolver: zodResolver(problemSchema),
    defaultValues: ticket?.problem || {
      title: '',
      description: '',
      version: 'Interlude C6',
      environment: 'test'
    }
  });

  const planForm = useForm<z.infer<typeof planSchema>>({
    resolver: zodResolver(planSchema),
    defaultValues: {
      files: ticket?.plan?.files.join('\n') || '',
      currentLogic: ticket?.plan?.currentLogic || '',
      minimalScope: ticket?.plan?.minimalScope || '',
      sourceImpact: ticket?.plan?.sourceImpact || '',
      risks: ticket?.plan?.risks || '',
      testPlan: ticket?.plan?.testPlan || ''
    }
  });

  // --- HANDLERS ---

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      const reader = new FileReader();
      
      const isImage = file.type.startsWith('image/');
      const type = isImage ? 'image' : 'log';

      reader.onload = (event) => {
        if (event.target?.result) {
          const newAttachment: Attachment = {
            id: Math.random().toString(36).substring(2, 9),
            name: file.name,
            type,
            content: event.target.result as string
          };
          setAttachments(prev => [...prev, newAttachment]);
        }
      };

      if (isImage) {
        reader.readAsDataURL(file);
      } else {
        reader.readAsText(file);
      }
    });
    
    // Clear input
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeAttachment = (attId: string) => {
    if (ticket && ticket.currentStep !== 'PROBLEM') return; // Read only if not in problem step
    setAttachments(prev => prev.filter(a => a.id !== attId));
  };

  const onProblemSubmit = (data: z.infer<typeof problemSchema>) => {
    const problemData = {
      ...data,
      attachments: attachments,
      // Fill required fields with defaults if missing
      environment: data.environment || 'test',
      version: data.version || 'Interlude C6',
      description: data.description || '',
      reproductionSteps: data.reproductionSteps || '',
      affectedAccounts: data.affectedAccounts || '',
      logs: data.logs || '',
      configDiff: data.configDiff || ''
    };

    if (isNew) {
      const newId = createTicket(problemData);
      setLocation(`/ticket/${newId}`);
    } else {
      // Logic to update...
    }
  };

  const onGenerateExpanded = () => {
    if (!ticket) return;
    generateExpanded(ticket.id, severity, selectedTags);
  };

  const onAcceptExpanded = () => {
    if (!ticket) return;
    acceptExpanded(ticket.id);
  };

  const onPlanSubmit = (data: z.infer<typeof planSchema>) => {
    if (!ticket) return;
    const fileArray = data.files.split('\n').filter(f => f.trim().length > 0);
    savePlan(ticket.id, { ...data, files: fileArray, markdown: '' });
  };

  // --- RENDER ---

  if (!isNew && !ticket) {
    return <Layout><div className="p-8">Nie znaleziono zgłoszenia</div></Layout>;
  }

  const currentStep = ticket?.currentStep || 'PROBLEM';

  return (
    <Layout>
      <div className="p-8 max-w-5xl mx-auto pb-32">
        <WorkflowStepper currentStep={currentStep} />

        {/* STEP 1: PROBLEM INPUT */}
        <Card className="bg-card border-white/5 shadow-2xl overflow-hidden mb-8">
          <CardHeader className="bg-white/5 border-b border-white/5">
            <CardTitle className="text-primary font-display tracking-wider flex items-center gap-2">
              <FileCode2 className="w-5 h-5" />
              1. DEFINICJA PROBLEMU
            </CardTitle>
          </CardHeader>
          <CardContent className="p-6">
            <Form {...problemForm}>
              <form onSubmit={problemForm.handleSubmit(onProblemSubmit)} className="space-y-6">
                
                {/* Simplified Header Section */}
                <div className="space-y-4">
                  <FormField
                    control={problemForm.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-lg">Tytuł Problemu <span className="text-red-500">*</span></FormLabel>
                        <FormControl>
                          <Input placeholder="Krótki opis błędu..." {...field} disabled={!!ticket && currentStep !== 'PROBLEM'} className="bg-black/20 text-lg py-6" />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={problemForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Opis (Opcjonalny)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Dodatkowe szczegóły..." {...field} disabled={!!ticket && currentStep !== 'PROBLEM'} className="min-h-[80px] bg-black/20 font-mono text-sm" />
                        </FormControl>
                        {field.value && <ComplianceCheck text={field.value} />}
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Attachments Section */}
                <div className="border rounded-lg p-4 border-dashed border-white/10 bg-black/10">
                   <div className="flex items-center justify-between mb-4">
                      <h3 className="text-sm font-medium text-muted-foreground flex items-center gap-2">
                        <Upload className="w-4 h-4" />
                        Załączniki (Zrzuty ekranu, Logi)
                      </h3>
                      {currentStep === 'PROBLEM' && (
                        <div className="relative">
                          <input
                            type="file"
                            multiple
                            onChange={handleFileUpload}
                            className="absolute inset-0 opacity-0 cursor-pointer"
                            ref={fileInputRef}
                          />
                          <Button type="button" variant="secondary" size="sm">
                            Dodaj Pliki
                          </Button>
                        </div>
                      )}
                   </div>

                   {attachments.length === 0 ? (
                      <div className="text-center py-4 text-xs text-muted-foreground/50">
                        Brak załączników
                      </div>
                   ) : (
                     <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {attachments.map((att) => (
                          <div key={att.id} className="relative group border border-white/10 rounded overflow-hidden bg-black/40">
                             {currentStep === 'PROBLEM' && (
                                <button
                                  type="button"
                                  onClick={() => removeAttachment(att.id)}
                                  className="absolute top-1 right-1 bg-red-500 text-white rounded-full p-0.5 opacity-0 group-hover:opacity-100 transition-opacity z-10"
                                >
                                  <X className="w-3 h-3" />
                                </button>
                             )}
                             
                             {att.type === 'image' ? (
                               <div className="aspect-video relative">
                                 <img src={att.content} alt={att.name} className="w-full h-full object-cover" />
                                 <div className="absolute bottom-0 left-0 right-0 bg-black/60 p-1 truncate text-[10px] text-white">
                                   {att.name}
                                 </div>
                               </div>
                             ) : (
                               <div className="aspect-video flex flex-col items-center justify-center p-2 text-muted-foreground">
                                 <FileTerminal className="w-8 h-8 mb-2" />
                                 <span className="text-[10px] truncate w-full text-center">{att.name}</span>
                               </div>
                             )}
                          </div>
                        ))}
                     </div>
                   )}
                </div>

                {/* Additional Fields (Collapsed/Optional) */}
                {/* We can hide these for the simple view or keep them minimal */}
                
                {currentStep === 'PROBLEM' && (
                  <Button type="submit" className="w-full bg-primary text-black font-bold hover:bg-primary/90 py-6 text-lg">
                    {isNew ? "Utwórz Zgłoszenie i Analizuj" : "Aktualizuj Problem"}
                  </Button>
                )}
              </form>
            </Form>
          </CardContent>
        </Card>

        {/* STEP 2: EXPANDED VIEW */}
        {ticket && (
          <Card className={cn("bg-card border-white/5 shadow-2xl overflow-hidden mb-8 transition-opacity duration-500", currentStep === 'PROBLEM' ? "opacity-50 pointer-events-none" : "opacity-100")}>
            <CardHeader className="bg-white/5 border-b border-white/5 flex flex-row items-center justify-between">
              <CardTitle className="text-primary font-display tracking-wider flex items-center gap-2">
                <FileText className="w-5 h-5" />
                2. ROZSZERZONA ANALIZA (PROBLEM EXPANDED)
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6 space-y-6">
              {currentStep === 'PROBLEM' ? (
                <div className="flex flex-col items-center justify-center p-8 border border-dashed border-white/10 rounded">
                  <p className="text-muted-foreground mb-4">Uzupełnij Definicję Problemu, aby kontynuować.</p>
                  
                  <div className="grid grid-cols-2 gap-4 w-full max-w-md">
                    <div className="space-y-2">
                      <label className="text-xs font-mono text-muted-foreground">Priorytet (Severity)</label>
                      <Select value={severity} onValueChange={(v) => setSeverity(v as TicketSeverity)}>
                        <SelectTrigger className="bg-black/20"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="S1">S1 - Krytyczny</SelectItem>
                          <SelectItem value="S2">S2 - Wysoki</SelectItem>
                          <SelectItem value="S3">S3 - Normalny</SelectItem>
                          <SelectItem value="S4">S4 - Niski</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                       <label className="text-xs font-mono text-muted-foreground">Kategoria (Tag)</label>
                       <Select onValueChange={(v) => setSelectedTags([v as TicketTag])}>
                        <SelectTrigger className="bg-black/20"><SelectValue placeholder="Główna kategoria" /></SelectTrigger>
                        <SelectContent>
                          {['Core','Datapack','Network','Geo','Economy','Security','AI'].map(t => (
                            <SelectItem key={t} value={t}>{t}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  <Button onClick={onGenerateExpanded} className="mt-4 w-full max-w-md bg-secondary hover:bg-secondary/80">
                    Generuj Rozszerzoną Analizę
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {/* Attachments Preview in Analysis */}
                  {ticket.problem.attachments.length > 0 && (
                    <div className="flex gap-2 overflow-x-auto pb-2 border-b border-white/5 mb-4">
                      {ticket.problem.attachments.map(att => (
                        att.type === 'image' && (
                           <div key={att.id} className="flex-shrink-0 w-32 h-20 rounded overflow-hidden border border-white/10">
                             <img src={att.content} className="w-full h-full object-cover" />
                           </div>
                        )
                      ))}
                    </div>
                  )}

                  <div className="bg-black/40 p-4 rounded border border-white/5 font-mono text-sm overflow-auto max-h-[500px]">
                    <div className="prose prose-invert prose-sm max-w-none text-muted-foreground">
                       <ReactMarkdown>
                          {ticket.expanded?.markdown || ''}
                       </ReactMarkdown>
                    </div>
                  </div>
                  
                  {currentStep === 'PROBLEM_EXPANDED' && (
                    <div className="flex items-center gap-4 p-4 bg-primary/5 border border-primary/20 rounded">
                       <Checkbox 
                        id="accept-expanded" 
                        onCheckedChange={(checked) => {
                          if (checked) onAcceptExpanded();
                        }}
                      />
                      <div className="flex-1">
                        <label htmlFor="accept-expanded" className="text-sm font-medium text-primary cursor-pointer">
                          Potwierdzam, że ta analiza pokrywa zakres problemu.
                        </label>
                        <p className="text-xs text-muted-foreground">Zatwierdzenie odblokowuje fazę Planowania. Ta akcja jest nieodwracalna.</p>
                      </div>
                    </div>
                  )}
                </div>
              )}
            </CardContent>
          </Card>
        )}

        {/* STEP 3: PLAN */}
        {ticket && ticket.expanded?.accepted && (
           <Card className="bg-card border-white/5 shadow-2xl overflow-hidden mb-8 animate-in slide-in-from-bottom-10 fade-in duration-500">
            <CardHeader className="bg-white/5 border-b border-white/5">
              <CardTitle className="text-primary font-display tracking-wider flex items-center gap-2">
                <Shield className="w-5 h-5" />
                3. PLAN IMPLEMENTACJI
              </CardTitle>
            </CardHeader>
            <CardContent className="p-6">
              {ticket.plan ? (
                 <div className="bg-black/40 p-4 rounded border border-white/5 font-mono text-sm">
                    <div className="prose prose-invert prose-sm max-w-none text-muted-foreground">
                      <ReactMarkdown>
                        {ticket.plan.markdown}
                      </ReactMarkdown>
                    </div>
                    <div className="mt-4 p-4 bg-green-500/10 border border-green-500/20 text-green-500 flex items-center gap-2 rounded">
                      <CheckCircle2 className="w-4 h-4" />
                      Plan Zatwierdzony
                    </div>
                 </div>
              ) : (
                <Form {...planForm}>
                  <form onSubmit={planForm.handleSubmit(onPlanSubmit)} className="space-y-6">
                    <Alert className="bg-amber-500/10 border-amber-500/20 text-amber-500">
                      <Lock className="w-4 h-4" />
                      <AlertTitle>Blokada Aktywna (Hard Block)</AlertTitle>
                      <AlertDescription>
                        Implementacja jest ściśle zablokowana do momentu zatwierdzenia Planu. Nie pisz kodu przed tym etapem.
                      </AlertDescription>
                    </Alert>

                    <FormField
                      control={planForm.control}
                      name="files"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Pliki Docelowe (Jeden na linię)</FormLabel>
                          <FormControl>
                            <Textarea placeholder="net.sf.l2j.gameserver.model.actor.L2Character.java" {...field} className="bg-black/20 font-mono text-xs" />
                          </FormControl>
                          <FormDescription>Użyj dokładnych ścieżek klas.</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                       <FormField
                        control={planForm.control}
                        name="currentLogic"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Obecna Logika</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Obecnie kalkulacja ignoruje..." {...field} className="bg-black/20 font-mono text-xs min-h-[100px]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <FormField
                        control={planForm.control}
                        name="minimalScope"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Minimalny Zakres Zmian</FormLabel>
                            <FormControl>
                              <Textarea placeholder="Zmodyfikuj walidację tylko w..." {...field} className="bg-black/20 font-mono text-xs min-h-[100px]" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <FormField
                      control={planForm.control}
                      name="risks"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Ryzyka i Regresje</FormLabel>
                          <FormControl>
                            <Textarea placeholder="Może zepsuć skille subklasy, jeśli..." {...field} className="bg-black/20 font-mono text-xs" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <div className="grid grid-cols-2 gap-4">
                      <FormField
                        control={planForm.control}
                        name="sourceImpact"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Source vs Runtime</FormLabel>
                            <FormControl>
                              <Input placeholder="Tylko Core / XML Datapacku" {...field} className="bg-black/20" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                       <FormField
                        control={planForm.control}
                        name="testPlan"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Plan Testów</FormLabel>
                            <FormControl>
                              <Input placeholder="Zresp moba ID 1234, uderz..." {...field} className="bg-black/20" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    <Button type="submit" className="w-full bg-primary text-black font-bold hover:bg-primary/90">
                      <Save className="w-4 h-4 mr-2" />
                      Zablokuj Plan i Odblokuj Implementację
                    </Button>
                  </form>
                </Form>
              )}
            </CardContent>
          </Card>
        )}
      </div>
    </Layout>
  );
}
