import Layout from '@/components/layout';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';

export default function About() {
  return (
    <Layout>
      <div className="p-8 max-w-4xl mx-auto">
        <h1 className="text-3xl font-display font-bold text-primary mb-6 text-glow">Zasady i Protokoły</h1>
        
        <div className="grid gap-6">
          <Card className="bg-card/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-xl">Główne Zasady</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4 text-muted-foreground">
              <div className="flex gap-4">
                <span className="text-primary font-bold font-mono">01</span>
                <p><strong>Brak Implementacji bez Planu.</strong> Artefakt PLAN.md jest obowiązkowy. Stanowi kontrakt określający co zostanie zmienione.</p>
              </div>
              <Separator className="bg-white/5" />
              <div className="flex gap-4">
                <span className="text-primary font-bold font-mono">02</span>
                <p><strong>Minimalny Zakres (Minimal Scope).</strong> Napraw błąd, nie refaktoryzuj systemu chyba że jest to absolutnie wymagane przez poprawkę. Regresje w Interlude są kosztowne.</p>
              </div>
               <Separator className="bg-white/5" />
              <div className="flex gap-4">
                <span className="text-primary font-bold font-mono">03</span>
                <p><strong>Zgodność z Interlude C6.</strong> To projekt konkretnej ery. Żadne funkcje z kronik Kamael, Gracia czy High Five nie są dozwolone. Zachowaj ścisłą autentyczność ery.</p>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card/50 border-white/5">
            <CardHeader>
              <CardTitle className="text-xl">Etapy Workflow</CardTitle>
            </CardHeader>
            <CardContent className="grid gap-4">
              <div className="p-4 rounded bg-black/20 border border-white/5">
                <h3 className="font-bold text-white mb-1">PROBLEM</h3>
                <p className="text-sm text-muted-foreground">Surowe dane ze zgłoszenia. Skup się na reprodukcji błędu.</p>
              </div>
              <div className="p-4 rounded bg-black/20 border border-white/5">
                <h3 className="font-bold text-white mb-1">ROZSZERZONY (EXPANDED)</h3>
                <p className="text-sm text-muted-foreground">Ustandaryzowana analiza z Priorytetem i Tagami. Pytania tu postawione muszą zostać rozwiązane.</p>
              </div>
              <div className="p-4 rounded bg-black/20 border border-white/5">
                <h3 className="font-bold text-white mb-1">PLAN</h3>
                <p className="text-sm text-muted-foreground">Techniczny plan działania. Wymaga zatwierdzenia, aby przejść do kodu.</p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </Layout>
  );
}
